# NSearch by Spec!

### TO USE: python3 nsearch.py "tag" "tag" -p "amount of pages to search" -o "result".txt

#!/usr/bin/python3

import requests
from bs4 import BeautifulSoup
import argparse
import time

# func to search nhentai by tag(s) and return codes and titles
def search_nhentai_by_tags(tags, start_page, max_pages=None):
    base_url = "https://nhentai.net"
    results = []
    page = start_page

    while True:
        # stop if max_pages is reached
        if max_pages and page > max_pages:
            break

        # generate search URL for the current page
        search_url = f"{base_url}/search/?q={' '.join(tags)}&page={page}"

        # fetch the search results page
        response = requests.get(search_url)
        if response.status_code != 200:
            print(f"Error fetching data from nhentai: {response.status_code}")
            break

        soup = BeautifulSoup(response.text, 'html.parser')
        galleries = soup.find_all('div', class_='gallery')

        # if no galleries are found on the current page, break the loop
        if not galleries:
            break

        # parse each gallery on the current page
        for gallery in galleries:
            code = gallery.find('a')['href'].split('/')[-2]  # extract code from URL
            title = gallery.find('div', class_='caption').text  # extract title
            results.append((code, title))

        # print progress
        print(f"Page {page}: Found {len(galleries)} results.")
        page += 1
        time.sleep(0.5)  # delay to prevent hitting the server too quickly

    return results, page

# save results to a text file in chunks
def save_results_to_txt(results, filename, append=False):
    mode = "a" if append else "w"
    with open(filename, mode) as f:
        for code, title in results:
            f.write(f"{code} - {title}\n")

# CLI interface setup
def main():
    parser = argparse.ArgumentParser(description="Search nhentai by tags/genres and save the results.")
    parser.add_argument("tags", nargs="+", help="Tags or genres to search for (space-separated)")
    parser.add_argument("-o", "--output", default="nhentai_results.txt", help="Output filename (default: nhentai_results.txt)")
    parser.add_argument("-p", "--pages", type=int, help="Number of pages to search (optional)")

    args = parser.parse_args()

    # search for tags
    print(f"Searching nhentai for tags: {', '.join(args.tags)}... This may take a while.")

    all_results = []
    page_chunk = 5
    page = 1
    total_pages_searched = 0

    while True:
        # fetch the results in chunks of up to 5 pages
        chunk_results, last_page = search_nhentai_by_tags(args.tags, start_page=page, max_pages=page + page_chunk - 1)

        if not chunk_results:
            break

        all_results.extend(chunk_results)
        total_pages_searched += (last_page - page)

        # save results to file after every chunk of 5 pages (or if fewer pages are available)
        print(f"Saving results after {min(page_chunk, (last_page - page))} pages...")
        save_results_to_txt(chunk_results, args.output, append=True)

        # set the starting page to the last processed page + 1
        page = last_page

        # stop if the user-specified page limit is reached
        if args.pages and total_pages_searched >= args.pages:
            break

        time.sleep(0.5)  # delay to avoid overwhelming the server (this may be an issue in the future if IP is flagged as a bot...)

    print("Done! All results saved.")

if __name__ == "__main__":
    main()
