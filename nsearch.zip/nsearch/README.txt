to use you must pip install BeautifulSoup and Requests.
